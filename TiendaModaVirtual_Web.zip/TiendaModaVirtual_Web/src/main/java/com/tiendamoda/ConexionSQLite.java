package com.tiendamoda.servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionSQLite {

    private static final String URL = "jdbc:sqlite:C:/Users/andre/Tienda de moda virtual.db";
    private static Connection connection = null;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // Cargar el driver
                Class.forName("org.sqlite.JDBC");

                // Conectar
                connection = DriverManager.getConnection(URL);
                System.out.println("Conexión exitosa a SQLite ✔");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("Error: No se encontró el Driver de SQLite");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos");
            e.printStackTrace();
        }
        return connection;
    }
}
