package com.tiendamoda;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "ProductoServlet", urlPatterns = {"/productos", "/ProductoServlet"})
public class ProductoServlet extends HttpServlet {

    // 🔹 GET = CONSULTAR LISTA DE PRODUCTOS
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Producto> lista = new ArrayList<>();

        String sql = "SELECT IdProducto, Nombre, Precio, Categoria FROM Producto";

        try (Connection conn = ConexionSQLite.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Producto p = new Producto();
                p.setIdProducto(rs.getInt("IdProducto"));
                p.setNombre(rs.getString("Nombre"));
                p.setPrecio(rs.getDouble("Precio"));
                p.setCategoria(rs.getString("Categoria"));
                lista.add(p);
            }

        } catch (SQLException e) {
            throw new ServletException("Error consultando productos", e);
        }

        // Enviar la lista a la JSP
        request.setAttribute("listaProductos", lista);
        request.getRequestDispatcher("productos.jsp").forward(request, response);
    }

    // 🔹 POST = INSERTAR NUEVO PRODUCTO (desde el formulario HTML/JSP)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String nombre = request.getParameter("nombre");
        String precioStr = request.getParameter("precio");
        String categoria = request.getParameter("categoria");

        double precio = 0.0;
        if (precioStr != null && !precioStr.isBlank()) {
            precio = Double.parseDouble(precioStr);
        }

        String sql = "INSERT INTO Producto (Nombre, Precio, Categoria) VALUES (?,?,?)";

        try (Connection conn = ConexionSQLite.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setDouble(2, precio);
            ps.setString(3, categoria);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new ServletException("Error insertando producto", e);
        }

        // Después de guardar, volvemos al listado (GET)
        response.sendRedirect("productos");
    }
}